# auto-generated file
import _cffi_backend

ffi = _cffi_backend.FFI('excel_to_pydict._native__ffi',
    _version = 0x2601,
    _types = b'\x00\x00\x04\x0D\x00\x00\x03\x03\x00\x00\x00\x0F\x00\x00\x02\x01\x00\x00\x00\x01',
    _globals = (b'\x00\x00\x00\x23print_xlsx_file',0,),
)
